import { createRouter, createWebHistory } from 'vue-router'
import NavigationPage from '@/views/NavigationPage.vue'
import SimplePage from '@/views/SimplePage.vue'
import ConfigEditor from '@/views/ConfigEditor.vue'

const routes = [
  {
    path: '/',
    name: 'navigation',
    component: NavigationPage,
    meta: {
      title: '导航页面',
      configFile: 'systemNavigation'
    }
  },
  {
    path: '/new',
    name: 'navigation-new',
    component: NavigationPage,
    meta: {
      title: '导航页面 - 新版',
      configFile: 'systemNavigationNew'
    }
  },
  {
    path: '/editor',
    name: 'config-editor',
    component: ConfigEditor,
    meta: {
      title: '配置编辑器'
    }
  },
  {
    path: '/search',
    name: 'search',
    component: SimplePage,
    meta: {
      title: '简洁搜索'
    }
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

// 设置页面标题
router.beforeEach((to) => {
  document.title = to.meta.title || '导航页面'
})

export default router
