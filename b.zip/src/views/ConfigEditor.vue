<template>
  <div class="config-editor min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
    <div class="max-w-7xl mx-auto">
      <!-- 头部操作栏 -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 mb-6">
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">配置编辑器</h1>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">拖拽标签调整顺序，完成后导出配置</p>
          </div>
          <div class="flex gap-3">
            <button
              @click="loadConfig"
              class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              重新加载
            </button>
            <button
              @click="exportConfig"
              class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              导出配置
            </button>
          </div>
        </div>
      </div>

      <!-- 分类列表 -->
      <div class="space-y-6">
        <div
          v-for="(category, catIndex) in config.categories"
          :key="catIndex"
          class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4">
            {{ category.name }}
          </h2>

          <!-- 子分类 -->
          <div v-if="category.subcategories && category.subcategories.length > 0" class="space-y-4">
            <div
              v-for="(subcategory, subIndex) in category.subcategories"
              :key="subIndex"
              class="border border-gray-200 dark:border-gray-700 rounded-lg p-4"
            >
              <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-3">
                {{ subcategory.name }}
              </h3>
              
              <!-- 可拖拽的标签列表 -->
              <draggable
                v-model="subcategory.tags"
                :group="`tags-${catIndex}-${subIndex}`"
                item-key="name"
                class="grid grid-cols-6 gap-3"
                @start="drag = true"
                @end="drag = false"
              >
                <template #item="{ element, index }">
                  <div
                    class="tag-item w-40 bg-gray-100 dark:bg-gray-700 rounded-lg p-2 cursor-move hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors group relative"
                  >
                    <div class="flex items-center gap-2 h-8">
                      <img
                        v-if="element.icon"
                        :src="element.icon"
                        :alt="element.name"
                        class="w-6 h-6 object-contain flex-shrink-0"
                      />
                      <span class="text-sm text-gray-900 dark:text-white truncate flex-1">
                        {{ element.name }}
                      </span>
                    </div>
                    <!-- 删除按钮 -->
                    <button
                      @click.stop="deleteTag(subcategory.tags, index)"
                      class="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs hover:bg-red-600"
                      title="删除"
                    >
                      ×
                    </button>
                  </div>
                </template>
              </draggable>
              
              <!-- 添加标签按钮 -->
              <button
                @click="addTag(subcategory.tags)"
                class="w-40 h-12 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:border-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500 transition-colors"
              >
                + 添加标签
              </button>
            </div>
          </div>

          <!-- 直接标签（无子分类） -->
          <div v-if="category.tags" class="grid grid-cols-6 gap-3">
            <draggable
              v-model="category.tags"
              :group="`tags-${catIndex}`"
              item-key="name"
              class="contents"
              @start="drag = true"
              @end="drag = false"
            >
              <template #item="{ element, index }">
                <div
                  class="tag-item w-40 bg-gray-100 dark:bg-gray-700 rounded-lg p-2 cursor-move hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors group relative"
                >
                  <div class="flex items-center gap-2 h-8">
                    <img
                      v-if="element.icon"
                      :src="element.icon"
                      :alt="element.name"
                      class="w-6 h-6 object-contain flex-shrink-0"
                    />
                    <span class="text-sm text-gray-900 dark:text-white truncate flex-1">
                      {{ element.name }}
                    </span>
                  </div>
                  <!-- 删除按钮 -->
                  <button
                    @click.stop="deleteTag(category.tags, index)"
                    class="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-xs hover:bg-red-600"
                    title="删除"
                  >
                    ×
                  </button>
                </div>
              </template>
            </draggable>
            
            <!-- 添加标签按钮 -->
            <button
              @click="addTag(category.tags)"
              class="w-40 h-12 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:border-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-500 transition-colors"
            >
              + 添加标签
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import draggable from 'vuedraggable'
import configData from '@/config/systemNavigationNew.json'

const config = ref({ categories: [] })
const drag = ref(false)

const loadConfig = () => {
  config.value = JSON.parse(JSON.stringify(configData))
}

const exportConfig = () => {
  const jsonStr = JSON.stringify(config.value, null, 2)
  const blob = new Blob([jsonStr], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'systemNavigationNew.json'
  a.click()
  URL.revokeObjectURL(url)
}

const deleteTag = (tags, index) => {
  if (confirm('确定要删除这个标签吗？')) {
    tags.splice(index, 1)
  }
}

const addTag = (tags) => {
  const name = prompt('请输入标签名称：')
  if (!name) return
  
  const url = prompt('请输入标签链接：')
  if (!url) return
  
  const icon = prompt('请输入图标路径（可选，直接回车跳过）：')
  
  const newTag = {
    name,
    url
  }
  
  if (icon) {
    newTag.icon = icon
  }
  
  tags.push(newTag)
}

onMounted(() => {
  loadConfig()
})
</script>

<style scoped>
.tag-item {
  user-select: none;
}

.sortable-ghost {
  opacity: 0.5;
  background: #3b82f6;
}

.sortable-drag {
  opacity: 0.8;
}
</style>
