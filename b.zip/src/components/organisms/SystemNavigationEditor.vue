<template>
  <div class="w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
      <h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100">
        系统导航编辑器
      </h2>
      <div class="flex gap-2">
        <button
          @click="saveChanges"
          class="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-semibold"
        >
          💾 保存配置
        </button>
        <button
          @click="resetConfig"
          class="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors"
        >
          重置为默认
        </button>
        <button
          @click="exportConfig"
          class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
        >
          导出 JSON
        </button>
        <button
          @click="showImportModal = true"
          class="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg transition-colors"
        >
          导入 JSON
        </button>
        <button
          @click="addCategory"
          class="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors"
        >
          添加分类
        </button>
      </div>
    </div>

    <!-- 分类列表 -->
    <div class="space-y-6">
      <div
        v-for="(category, catIndex) in editableCategories"
        :key="catIndex"
        class="border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4"
      >
        <!-- 一级分类 -->
        <div class="flex items-center gap-4 mb-4">
          <input
            v-model="category.name"
            placeholder="分类名称"
            class="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
          <button
            @click="moveCategoryUp(catIndex)"
            :disabled="catIndex === 0"
            class="px-3 py-2 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg text-sm"
          >
            ↑
          </button>
          <button
            @click="moveCategoryDown(catIndex)"
            :disabled="catIndex === editableCategories.length - 1"
            class="px-3 py-2 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg text-sm"
          >
            ↓
          </button>
          <button
            @click="addTagToCategory(catIndex)"
            class="px-3 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm"
          >
            添加标签
          </button>
          <button
            @click="addSubcategory(catIndex)"
            class="px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm"
          >
            添加子分类
          </button>
          <button
            @click="removeCategory(catIndex)"
            class="px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm"
          >
            删除
          </button>
        </div>

        <!-- 一级分类直接的标签列表 -->
        <div v-if="category.tags && category.tags.length > 0" class="ml-6 mb-4 space-y-2">
          <div class="text-sm text-gray-600 dark:text-gray-400 mb-2">一级分类标签：</div>
          <div
            v-for="(tag, tagIndex) in category.tags"
            :key="`cat-tag-${tagIndex}`"
            class="flex items-center gap-2 bg-white dark:bg-gray-800 p-2 rounded border border-gray-200 dark:border-gray-600"
          >
            <input
              v-model="tag.name"
              placeholder="标签名称"
              class="w-32 px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
            />
            <input
              v-model="tag.url"
              placeholder="URL"
              class="flex-1 px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
            />
            <div class="flex items-center gap-2">
              <img
                v-if="tag.icon"
                :src="tag.icon"
                class="w-6 h-6 object-contain"
                alt="图标预览"
              />
              <input
                type="file"
                accept="image/*"
                @change="handleCategoryIconUpload($event, catIndex, tagIndex)"
                class="hidden"
                :ref="el => setCategoryFileInputRef(el, catIndex, tagIndex)"
              />
              <button
                @click="triggerCategoryFileInput(catIndex, tagIndex)"
                class="px-2 py-1 bg-purple-500 hover:bg-purple-600 text-white rounded text-sm whitespace-nowrap"
              >
                上传图标
              </button>
            </div>
            <button
              @click="moveCategoryTagUp(catIndex, tagIndex)"
              :disabled="tagIndex === 0"
              class="px-2 py-1 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded text-sm"
            >
              ↑
            </button>
            <button
              @click="moveCategoryTagDown(catIndex, tagIndex)"
              :disabled="tagIndex === category.tags.length - 1"
              class="px-2 py-1 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded text-sm"
            >
              ↓
            </button>
            <button
              @click="removeCategoryTag(catIndex, tagIndex)"
              class="px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-sm"
            >
              删除
            </button>
          </div>
        </div>

        <!-- 二级分类列表 -->
        <div class="ml-6 space-y-4">
          <div
            v-for="(subcategory, subIndex) in category.subcategories"
            :key="subIndex"
            class="border border-gray-300 dark:border-gray-600 rounded-lg p-3 bg-gray-50 dark:bg-gray-700"
          >
            <!-- 二级分类 -->
            <div class="flex items-center gap-3 mb-3">
              <input
                v-model="subcategory.name"
                placeholder="子分类名称"
                class="flex-1 px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 text-sm"
              />
              <button
                @click="moveSubcategoryUp(catIndex, subIndex)"
                :disabled="subIndex === 0"
                class="px-2 py-1.5 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg text-sm"
              >
                ↑
              </button>
              <button
                @click="moveSubcategoryDown(catIndex, subIndex)"
                :disabled="subIndex === category.subcategories.length - 1"
                class="px-2 py-1.5 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg text-sm"
              >
                ↓
              </button>
              <button
                @click="addTag(catIndex, subIndex)"
                class="px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm"
              >
                添加标签
              </button>
              <button
                @click="removeSubcategory(catIndex, subIndex)"
                class="px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm"
              >
                删除
              </button>
            </div>

            <!-- 标签列表 -->
            <div class="ml-4 space-y-2">
              <div
                v-for="(tag, tagIndex) in subcategory.tags"
                :key="tagIndex"
                class="flex items-center gap-2 bg-white dark:bg-gray-800 p-2 rounded border border-gray-200 dark:border-gray-600"
              >
                <input
                  v-model="tag.name"
                  placeholder="标签名称"
                  class="w-32 px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                />
                <input
                  v-model="tag.url"
                  placeholder="URL"
                  class="flex-1 px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-sm"
                />
                <div class="flex items-center gap-2">
                  <img
                    v-if="tag.icon"
                    :src="tag.icon"
                    class="w-6 h-6 object-contain"
                    alt="图标预览"
                  />
                  <input
                    type="file"
                    accept="image/*"
                    @change="handleIconUpload($event, catIndex, subIndex, tagIndex)"
                    class="hidden"
                    :ref="el => setFileInputRef(el, catIndex, subIndex, tagIndex)"
                  />
                  <button
                    @click="triggerFileInput(catIndex, subIndex, tagIndex)"
                    class="px-2 py-1 bg-purple-500 hover:bg-purple-600 text-white rounded text-sm whitespace-nowrap"
                  >
                    上传图标
                  </button>
                </div>
                <button
                  @click="moveTagUp(catIndex, subIndex, tagIndex)"
                  :disabled="tagIndex === 0"
                  class="px-2 py-1 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded text-sm"
                >
                  ↑
                </button>
                <button
                  @click="moveTagDown(catIndex, subIndex, tagIndex)"
                  :disabled="tagIndex === subcategory.tags.length - 1"
                  class="px-2 py-1 bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded text-sm"
                >
                  ↓
                </button>
                <button
                  @click="removeTag(catIndex, subIndex, tagIndex)"
                  class="px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-sm"
                >
                  删除
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 导入模态框 -->
    <div
      v-if="showImportModal"
      class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
      @click.self="showImportModal = false"
    >
      <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full">
        <h3 class="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">
          导入配置
        </h3>
        <textarea
          v-model="importText"
          placeholder="粘贴 JSON 配置..."
          class="w-full h-64 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 font-mono text-sm"
        ></textarea>
        <div class="flex justify-end gap-2 mt-4">
          <button
            @click="showImportModal = false"
            class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg"
          >
            取消
          </button>
          <button
            @click="importConfig"
            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg"
          >
            导入
          </button>
        </div>
      </div>
    </div>

    <!-- 导出模态框 -->
    <div
      v-if="showExportModal"
      class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
      @click.self="showExportModal = false"
    >
      <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full">
        <h3 class="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">
          导出配置
        </h3>
        <textarea
          :value="exportText"
          readonly
          class="w-full h-64 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 font-mono text-sm"
          @click="$event.target.select()"
        ></textarea>
        <p class="text-sm text-gray-600 dark:text-gray-400 mt-2">
          点击文本框自动全选，然后复制粘贴到 systemNavigation.json 文件
        </p>
        <div class="flex justify-end gap-2 mt-4">
          <button
            @click="copyToClipboard"
            class="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg"
          >
            复制到剪贴板
          </button>
          <button
            @click="showExportModal = false"
            class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg"
          >
            关闭
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useSystemNavigation } from '@/composables/useSystemNavigation'

const { saveConfig, resetToDefault } = useSystemNavigation()

const editableCategories = ref([])
const showImportModal = ref(false)
const showExportModal = ref(false)
const importText = ref('')
const exportText = ref('')
const fileInputRefs = ref({})

// 从 LocalStorage 或默认配置加载
const loadCurrentConfig = () => {
  const storage = localStorage.getItem('system_navigation')
  if (storage) {
    const config = JSON.parse(storage)
    editableCategories.value = JSON.parse(JSON.stringify(config.categories))
  } else {
    // 加载默认配置
    import('@/config/systemNavigation.json').then(module => {
      editableCategories.value = JSON.parse(JSON.stringify(module.default.categories))
    })
  }
}

// 初始化加载
loadCurrentConfig()

// 保存配置
const saveChanges = () => {
  if (saveConfig(editableCategories.value)) {
    alert('保存成功！页面将刷新以显示更新')
    window.location.reload()
  } else {
    alert('保存失败，请重试')
  }
}

// 重置为默认配置
const resetConfig = () => {
  if (confirm('确定要重置为默认配置吗？这将清除所有自定义内容。')) {
    if (resetToDefault()) {
      alert('已重置为默认配置！页面将刷新')
      window.location.reload()
    } else {
      alert('重置失败，请重试')
    }
  }
}

const setFileInputRef = (el, catIndex, subIndex, tagIndex) => {
  if (el) {
    const key = `${catIndex}-${subIndex}-${tagIndex}`
    fileInputRefs.value[key] = el
  }
}

const triggerFileInput = (catIndex, subIndex, tagIndex) => {
  const key = `${catIndex}-${subIndex}-${tagIndex}`
  const input = fileInputRefs.value[key]
  if (input) {
    input.click()
  }
}

const handleIconUpload = (event, catIndex, subIndex, tagIndex) => {
  const file = event.target.files[0]
  if (!file) return

  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    alert('请选择图片文件')
    return
  }

  // 检查文件大小（限制为 500KB）
  if (file.size > 500 * 1024) {
    alert('图片文件太大，请选择小于 500KB 的图片')
    return
  }

  const reader = new FileReader()
  reader.onload = (e) => {
    // 使用响应式更新
    const categories = [...editableCategories.value]
    categories[catIndex].subcategories[subIndex].tags[tagIndex].icon = e.target.result
    editableCategories.value = categories
  }
  reader.onerror = () => {
    alert('读取文件失败')
  }
  reader.readAsDataURL(file)
}

const addCategory = () => {
  editableCategories.value.push({
    name: '新分类',
    subcategories: [],
    tags: []
  })
}

const removeCategory = (index) => {
  if (confirm('确定要删除这个分类吗？')) {
    editableCategories.value.splice(index, 1)
  }
}

const moveCategoryUp = (index) => {
  if (index > 0) {
    const temp = editableCategories.value[index]
    editableCategories.value[index] = editableCategories.value[index - 1]
    editableCategories.value[index - 1] = temp
  }
}

const moveCategoryDown = (index) => {
  if (index < editableCategories.value.length - 1) {
    const temp = editableCategories.value[index]
    editableCategories.value[index] = editableCategories.value[index + 1]
    editableCategories.value[index + 1] = temp
  }
}

// 一级分类标签管理
const addTagToCategory = (catIndex) => {
  const category = editableCategories.value[catIndex]
  if (!category.tags) {
    category.tags = []
  }
  category.tags.push({
    name: '新标签',
    url: 'https://example.com',
    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="%23999"/></svg>'
  })
}

const removeCategoryTag = (catIndex, tagIndex) => {
  if (confirm('确定要删除这个标签吗？')) {
    editableCategories.value[catIndex].tags.splice(tagIndex, 1)
  }
}

const moveCategoryTagUp = (catIndex, tagIndex) => {
  if (tagIndex > 0) {
    const tags = editableCategories.value[catIndex].tags
    const temp = tags[tagIndex]
    tags[tagIndex] = tags[tagIndex - 1]
    tags[tagIndex - 1] = temp
  }
}

const moveCategoryTagDown = (catIndex, tagIndex) => {
  const tags = editableCategories.value[catIndex].tags
  if (tagIndex < tags.length - 1) {
    const temp = tags[tagIndex]
    tags[tagIndex] = tags[tagIndex + 1]
    tags[tagIndex + 1] = temp
  }
}

const categoryFileInputRefs = ref({})

const setCategoryFileInputRef = (el, catIndex, tagIndex) => {
  if (el) {
    const key = `cat-${catIndex}-${tagIndex}`
    categoryFileInputRefs.value[key] = el
  }
}

const triggerCategoryFileInput = (catIndex, tagIndex) => {
  const key = `cat-${catIndex}-${tagIndex}`
  const input = categoryFileInputRefs.value[key]
  if (input) {
    input.click()
  }
}

const handleCategoryIconUpload = (event, catIndex, tagIndex) => {
  const file = event.target.files[0]
  if (!file) return

  if (!file.type.startsWith('image/')) {
    alert('请选择图片文件')
    return
  }

  if (file.size > 500 * 1024) {
    alert('图片文件太大，请选择小于 500KB 的图片')
    return
  }

  const reader = new FileReader()
  reader.onload = (e) => {
    // 使用响应式更新
    const categories = [...editableCategories.value]
    categories[catIndex].tags[tagIndex].icon = e.target.result
    editableCategories.value = categories
  }
  reader.onerror = () => {
    alert('读取文件失败')
  }
  reader.readAsDataURL(file)
}

const addSubcategory = (catIndex) => {
  const category = editableCategories.value[catIndex]
  if (!category.subcategories) {
    category.subcategories = []
  }
  category.subcategories.push({
    name: '新子分类',
    tags: []
  })
}

const removeSubcategory = (catIndex, subIndex) => {
  if (confirm('确定要删除这个子分类吗？')) {
    editableCategories.value[catIndex].subcategories.splice(subIndex, 1)
  }
}

const moveSubcategoryUp = (catIndex, subIndex) => {
  if (subIndex > 0) {
    const subs = editableCategories.value[catIndex].subcategories
    const temp = subs[subIndex]
    subs[subIndex] = subs[subIndex - 1]
    subs[subIndex - 1] = temp
  }
}

const moveSubcategoryDown = (catIndex, subIndex) => {
  const subs = editableCategories.value[catIndex].subcategories
  if (subIndex < subs.length - 1) {
    const temp = subs[subIndex]
    subs[subIndex] = subs[subIndex + 1]
    subs[subIndex + 1] = temp
  }
}

const addTag = (catIndex, subIndex) => {
  const subcategory = editableCategories.value[catIndex].subcategories[subIndex]
  if (!subcategory.tags) {
    subcategory.tags = []
  }
  subcategory.tags.push({
    name: '新标签',
    url: 'https://example.com',
    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="%23999"/></svg>'
  })
}

const removeTag = (catIndex, subIndex, tagIndex) => {
  if (confirm('确定要删除这个标签吗？')) {
    editableCategories.value[catIndex].subcategories[subIndex].tags.splice(tagIndex, 1)
  }
}

const moveTagUp = (catIndex, subIndex, tagIndex) => {
  if (tagIndex > 0) {
    const tags = editableCategories.value[catIndex].subcategories[subIndex].tags
    const temp = tags[tagIndex]
    tags[tagIndex] = tags[tagIndex - 1]
    tags[tagIndex - 1] = temp
  }
}

const moveTagDown = (catIndex, subIndex, tagIndex) => {
  const tags = editableCategories.value[catIndex].subcategories[subIndex].tags
  if (tagIndex < tags.length - 1) {
    const temp = tags[tagIndex]
    tags[tagIndex] = tags[tagIndex + 1]
    tags[tagIndex + 1] = temp
  }
}

const exportConfig = () => {
  const config = {
    version: '1.0',
    categories: editableCategories.value
  }
  exportText.value = JSON.stringify(config, null, 2)
  showExportModal.value = true
}

const importConfig = () => {
  try {
    const config = JSON.parse(importText.value)
    if (config.categories && Array.isArray(config.categories)) {
      editableCategories.value = config.categories
      showImportModal.value = false
      importText.value = ''
      alert('导入成功！记得点击"保存配置"按钮保存更改')
    } else {
      alert('配置格式错误：缺少 categories 数组')
    }
  } catch (e) {
    alert('导入失败：JSON 格式错误\n' + e.message)
  }
}

const copyToClipboard = async () => {
  try {
    await navigator.clipboard.writeText(exportText.value)
    alert('已复制到剪贴板！')
  } catch (e) {
    alert('复制失败，请手动选择并复制')
  }
}
</script>
