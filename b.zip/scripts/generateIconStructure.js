import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 读取配置文件
const configPath = path.join(__dirname, '../src/config/systemNavigationNew.json')
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))

// 输出目录
const outputDir = path.join(__dirname, '../public/icons-new')

// 创建目录
function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
}

// 中文转拼音映射（简化版）
const pinyinMap = {
  '生活工具': 'LifeTools',
  '办公学习': 'OfficeStudy',
  '搜索': 'Search',
  '影音娱乐': 'Entertainment',
  '游戏': 'Game',
  '购物': 'Shopping',
  'AI工具': 'AITools',
  '开发设计': 'Development',
  '资讯': 'News',
  '社交': 'Social',
  '办公': 'Office',
  '邮箱': 'Email',
  '地图': 'Map',
  '出行': 'Travel',
  '外卖': 'Food',
  '文档': 'Document',
  '工具': 'Tools',
  '网盘': 'CloudStorage',
  '学习': 'Learning',
  '视频': 'Video',
  '短视频': 'ShortVideo',
  '直播': 'Live',
  '音乐': 'Music',
  '平台': 'Platform',
  '手游': 'MobileGame',
  '综合': 'General',
  '二手': 'SecondHand',
  '海外': 'Overseas',
  '对话': 'Chat',
  '编程': 'Coding',
  '图像': 'Image',
  '代码托管': 'CodeHosting',
  '开发工具': 'DevTools',
  '开发文档': 'DevDocs',
  '设计工具': 'DesignTools',
  '设计资源': 'DesignResources',
  '科技': 'Tech',
  '财经': 'Finance',
  '体育': 'Sports',
  '娱乐': 'Entertainment'
}

// 创建1x1透明PNG占位图
function createPlaceholderPNG(filePath) {
  // 1x1 透明PNG的base64数据
  const pngData = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'base64'
  )
  fs.writeFileSync(filePath, pngData)
}

// 处理标签名称，生成文件名
function sanitizeFileName(name) {
  // 移除特殊字符，保留中英文、数字、空格
  return name.replace(/[<>:"/\\|?*]/g, '').trim()
}

// 生成图标结构
function generateIconStructure() {
  console.log('开始生成图标文件结构...\n')
  
  let totalFiles = 0
  const structure = []

  config.categories.forEach(category => {
    const categoryEn = pinyinMap[category.name] || category.name
    const categoryDir = path.join(outputDir, categoryEn)
    ensureDir(categoryDir)
    
    structure.push(`${categoryEn}/`)
    
    // 处理子分类
    if (category.subcategories && category.subcategories.length > 0) {
      category.subcategories.forEach(subcategory => {
        const subcategoryEn = pinyinMap[subcategory.name] || subcategory.name
        const subcategoryDir = path.join(categoryDir, subcategoryEn)
        ensureDir(subcategoryDir)
        
        structure.push(`  ${subcategoryEn}/`)
        
        // 生成标签图标
        subcategory.tags.forEach(tag => {
          const fileName = sanitizeFileName(tag.name) + '.png'
          const filePath = path.join(subcategoryDir, fileName)
          createPlaceholderPNG(filePath)
          structure.push(`    ${fileName}`)
          totalFiles++
        })
      })
    }
    
    // 处理直接标签
    if (category.tags && category.tags.length > 0) {
      category.tags.forEach(tag => {
        const fileName = sanitizeFileName(tag.name) + '.png'
        const filePath = path.join(categoryDir, fileName)
        createPlaceholderPNG(filePath)
        structure.push(`  ${fileName}`)
        totalFiles++
      })
    }
    
    structure.push('')
  })

  // 输出目录结构
  console.log('生成的目录结构：')
  console.log('================')
  structure.forEach(line => console.log(line))
  console.log('================')
  console.log(`\n总共生成 ${totalFiles} 个占位图标文件`)
  console.log(`输出目录: ${outputDir}`)
  
  // 生成路径映射文件
  generatePathMapping()
}

// 生成路径映射文件，方便后续替换
function generatePathMapping() {
  const mapping = []
  
  config.categories.forEach(category => {
    const categoryEn = pinyinMap[category.name] || category.name
    
    if (category.subcategories && category.subcategories.length > 0) {
      category.subcategories.forEach(subcategory => {
        const subcategoryEn = pinyinMap[subcategory.name] || subcategory.name
        
        subcategory.tags.forEach(tag => {
          const fileName = sanitizeFileName(tag.name) + '.png'
          const iconPath = `/icons-new/${categoryEn}/${subcategoryEn}/${fileName}`
          mapping.push({
            name: tag.name,
            url: tag.url,
            iconPath: iconPath,
            category: category.name,
            subcategory: subcategory.name
          })
        })
      })
    }
    
    if (category.tags && category.tags.length > 0) {
      category.tags.forEach(tag => {
        const fileName = sanitizeFileName(tag.name) + '.png'
        const iconPath = `/icons-new/${categoryEn}/${fileName}`
        mapping.push({
          name: tag.name,
          url: tag.url,
          iconPath: iconPath,
          category: category.name,
          subcategory: null
        })
      })
    }
  })
  
  const mappingPath = path.join(outputDir, 'icon-mapping.json')
  fs.writeFileSync(mappingPath, JSON.stringify(mapping, null, 2), 'utf-8')
  console.log(`\n路径映射文件已生成: ${mappingPath}`)
}

// 执行生成
try {
  generateIconStructure()
  console.log('\n✅ 图标结构生成完成！')
  console.log('\n📝 接下来你可以：')
  console.log('1. 将真实的图标文件替换到对应的位置')
  console.log('2. 参考 icon-mapping.json 文件查看每个标签对应的图标路径')
  console.log('3. 使用脚本批量更新配置文件中的 icon 路径')
} catch (error) {
  console.error('❌ 生成失败:', error)
}
