import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 读取配置文件
const configPath = path.join(__dirname, '../src/config/systemNavigationNew.json')
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))

// 目录路径
const oldIconsDir = path.join(__dirname, '../public/icons-')
const newIconsDir = path.join(__dirname, '../public/icons')

// 统计信息
let stats = {
  total: 0,
  copied: 0,
  notFound: 0,
  skipped: 0
}

// 扫描旧文件夹，建立文件名到路径的映射
const oldIconFiles = new Map()

function scanOldIcons(dir, relativePath = '') {
  const items = fs.readdirSync(dir)
  
  items.forEach(item => {
    const fullPath = path.join(dir, item)
    const stat = fs.statSync(fullPath)
    
    if (stat.isDirectory()) {
      scanOldIcons(fullPath, path.join(relativePath, item))
    } else if (stat.isFile()) {
      // 提取文件名（不含扩展名）
      const nameWithoutExt = path.parse(item).name
      const ext = path.parse(item).ext
      
      // 存储多个可能的匹配键
      oldIconFiles.set(item, fullPath) // 完整文件名
      oldIconFiles.set(nameWithoutExt, fullPath) // 不含扩展名
      
      // 处理特殊情况
      if (nameWithoutExt.toLowerCase() === 'mysql') {
        oldIconFiles.set('MySQL', fullPath)
      }
    }
  })
}

// 复制文件
function copyFile(src, dest) {
  try {
    const destDir = path.dirname(dest)
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true })
    }
    
    fs.copyFileSync(src, dest)
    return true
  } catch (error) {
    console.error(`  ❌ 复制失败: ${error.message}`)
    return false
  }
}

// 查找旧图标文件（智能匹配）
function findOldIconSmart(tagName) {
  // 尝试多种匹配方式
  const searchKeys = [
    tagName,                          // 原始名称
    tagName + '.png',                 // 加.png
    tagName + '.jpg',                 // 加.jpg
    tagName + '.svg',                 // 加.svg
    tagName.toLowerCase(),            // 小写
    tagName.toUpperCase(),            // 大写
  ]
  
  for (const key of searchKeys) {
    if (oldIconFiles.has(key)) {
      return oldIconFiles.get(key)
    }
  }
  
  return null
}

// 中文转拼音映射
const pinyinMap = {
  '生活工具': 'LifeTools',
  '办公学习': 'OfficeStudy',
  '搜索': 'Search',
  '影音娱乐': 'Entertainment',
  '游戏': 'Game',
  '购物': 'Shopping',
  'AI工具': 'AITools',
  '开发设计': 'Development',
  '资讯': 'News',
  '社交': 'Social',
  '办公': 'Office',
  '邮箱': 'Email',
  '地图': 'Map',
  '出行': 'Travel',
  '外卖': 'Food',
  '文档': 'Document',
  '工具': 'Tools',
  '网盘': 'CloudStorage',
  '学习': 'Learning',
  '视频': 'Video',
  '短视频': 'ShortVideo',
  '直播': 'Live',
  '音乐': 'Music',
  '平台': 'Platform',
  '手游': 'MobileGame',
  '综合': 'General',
  '二手': 'SecondHand',
  '海外': 'Overseas',
  '对话': 'Chat',
  '编程': 'Coding',
  '图像': 'Image',
  '代码托管': 'CodeHosting',
  '开发工具': 'DevTools',
  '开发文档': 'DevDocs',
  '设计工具': 'DesignTools',
  '设计资源': 'DesignResources',
  '科技': 'Tech',
  '财经': 'Finance',
  '体育': 'Sports',
  '娱乐': 'Entertainment'
}

// 处理标签名称
function sanitizeFileName(name) {
  return name.replace(/[<>:"/\\|?*]/g, '').trim()
}

// 获取新图标路径
function getNewIconPath(categoryName, subcategoryName, tagName) {
  const categoryEn = pinyinMap[categoryName] || categoryName
  const fileName = sanitizeFileName(tagName) + '.png'
  
  if (subcategoryName) {
    const subcategoryEn = pinyinMap[subcategoryName] || subcategoryName
    return path.join(newIconsDir, categoryEn, subcategoryEn, fileName)
  } else {
    return path.join(newIconsDir, categoryEn, fileName)
  }
}

// 迁移图标
function migrateIcons() {
  console.log('🔍 扫描旧图标文件夹...\n')
  scanOldIcons(oldIconsDir)
  console.log(`📋 找到 ${oldIconFiles.size} 个旧图标文件\n`)
  
  console.log('🚀 开始智能迁移图标...\n')
  console.log('=' .repeat(60))
  
  config.categories.forEach(category => {
    console.log(`\n📁 ${category.name}`)
    
    // 处理子分类
    if (category.subcategories && category.subcategories.length > 0) {
      category.subcategories.forEach(subcategory => {
        console.log(`  📂 ${subcategory.name}`)
        
        subcategory.tags.forEach(tag => {
          stats.total++
          const newIconPath = getNewIconPath(category.name, subcategory.name, tag.name)
          
          // 检查新位置是否已存在文件（且不是占位符）
          if (fs.existsSync(newIconPath)) {
            const fileSize = fs.statSync(newIconPath).size
            if (fileSize > 100) {
              console.log(`    ⏭️  ${tag.name} - 已存在，跳过`)
              stats.skipped++
              return
            }
          }
          
          // 智能查找旧图标
          const oldIconFile = findOldIconSmart(tag.name)
          
          if (oldIconFile) {
            if (copyFile(oldIconFile, newIconPath)) {
              console.log(`    ✅ ${tag.name} - 已复制`)
              stats.copied++
            } else {
              stats.notFound++
            }
          } else {
            console.log(`    ⚪ ${tag.name} - 未找到`)
            stats.notFound++
          }
        })
      })
    }
    
    // 处理直接标签
    if (category.tags && category.tags.length > 0) {
      category.tags.forEach(tag => {
        stats.total++
        const newIconPath = getNewIconPath(category.name, null, tag.name)
        
        // 检查新位置是否已存在文件
        if (fs.existsSync(newIconPath)) {
          const fileSize = fs.statSync(newIconPath).size
          if (fileSize > 100) {
            console.log(`  ⏭️  ${tag.name} - 已存在，跳过`)
            stats.skipped++
            return
          }
        }
        
        // 智能查找旧图标
        const oldIconFile = findOldIconSmart(tag.name)
        
        if (oldIconFile) {
          if (copyFile(oldIconFile, newIconPath)) {
            console.log(`  ✅ ${tag.name} - 已复制`)
            stats.copied++
          } else {
            stats.notFound++
          }
        } else {
          console.log(`  ⚪ ${tag.name} - 未找到`)
          stats.notFound++
        }
      })
    }
  })
  
  console.log('\n' + '='.repeat(60))
  console.log('\n📊 迁移统计:')
  console.log(`  总标签数: ${stats.total}`)
  console.log(`  ✅ 成功复制: ${stats.copied}`)
  console.log(`  ⏭️  已存在跳过: ${stats.skipped}`)
  console.log(`  ⚪ 未找到: ${stats.notFound}`)
  console.log(`\n✨ 迁移完成！`)
}

// 执行迁移
try {
  migrateIcons()
} catch (error) {
  console.error('❌ 迁移失败:', error)
  console.error(error.stack)
}
